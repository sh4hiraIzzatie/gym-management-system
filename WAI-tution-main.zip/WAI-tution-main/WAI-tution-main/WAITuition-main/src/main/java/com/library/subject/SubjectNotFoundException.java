package com.library.subject;

public class SubjectNotFoundException extends Throwable {
}
